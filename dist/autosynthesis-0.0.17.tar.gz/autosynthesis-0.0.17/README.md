# autosynthesis
The Automated Process Synthesis and Design package.
